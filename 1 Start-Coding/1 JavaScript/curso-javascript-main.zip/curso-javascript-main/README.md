# Curso Javascript

El presente repositorio contiene el código desarrollado a lo largo del curso de Javascript dictado por Alexis Lazzuri para la fundación StartCoding. En el mismo se incluyen los ejemplos y ejercicios planteados a lo largo de la clase, asi como los diferentes challenges propuestos para cada módulo junto con la forma de resolución explicada en los videos del curso.
