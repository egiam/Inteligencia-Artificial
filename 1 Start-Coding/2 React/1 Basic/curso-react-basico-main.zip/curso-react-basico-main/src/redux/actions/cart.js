export const addElementToCart = (product) => {
 return {
     type:'PUSH NEW PRODUCT',
     payload: product
 }
}