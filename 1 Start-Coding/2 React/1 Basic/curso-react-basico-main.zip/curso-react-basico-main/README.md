# Curso básico de React 👩‍💻👨‍💻

Este repositorio contiene el código desarrollado a lo largo del curso de React Básico por Cristian Hourcade para la fundación StartCoding. En el mismo se incluyen los ejemplos y ejercicios planteados a lo largo de la clase, asi como los diferentes challenges propuestos para cada módulo junto con la forma de resolución explicada en los videos del curso.

## Recordatorio

Al descargar el Repositorio, recordá que para que funcione, debes utilizar NPM INSTALL y despues NPM START.